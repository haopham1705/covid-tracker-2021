import { GlobalActions } from './slices/globalSlice'
export { GlobalActions }
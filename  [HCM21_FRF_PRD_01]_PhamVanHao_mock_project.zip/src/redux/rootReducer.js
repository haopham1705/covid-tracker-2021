import { combineReducers } from 'redux'
import { GlobalReducer } from './slices/globalSlice'

const rootReducer = combineReducers({
    GlobalReducer
});

export default rootReducer;
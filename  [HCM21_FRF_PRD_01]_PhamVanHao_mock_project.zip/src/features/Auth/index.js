import Login from './components/Login'
import Register from './components/Register'

export { Login, Register }
import React from 'react'

export default function ReadNews() {
    return (
        <div>
            
        </div>
    )
}
